import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useJobStore, Job } from '../stores/jobStore';
import { useAuthStore } from '../stores/authStore';

const PostJobPage = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editJobId = searchParams.get('edit');
  const { jobs } = useJobStore();
  const { user } = useAuthStore();

  const [formData, setFormData] = useState({
    title: '',
    category: '',
    jobType: '',
    location: '',
    salary: '',
    description: '',
    requirements: '',
    benefits: '',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = editJobId 
      ? `Edit Job | JobNest` 
      : `Post a Job | JobNest`;
    
    // If editing, populate form with job data
    if (editJobId) {
      const jobToEdit = jobs.find(job => job.id === editJobId);
      if (jobToEdit) {
        setFormData({
          title: jobToEdit.title,
          category: jobToEdit.category,
          jobType: jobToEdit.jobType,
          location: jobToEdit.location,
          salary: jobToEdit.salary,
          description: jobToEdit.description,
          requirements: jobToEdit.requirements.join('\n'),
          benefits: jobToEdit.benefits.join('\n'),
        });
      }
    }
  }, [editJobId, jobs]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when field is changed
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.title.trim()) errors.title = 'Job title is required';
    if (!formData.category) errors.category = 'Category is required';
    if (!formData.jobType) errors.jobType = 'Job type is required';
    if (!formData.location.trim()) errors.location = 'Location is required';
    if (!formData.salary.trim()) errors.salary = 'Salary information is required';
    if (!formData.description.trim()) errors.description = 'Job description is required';
    if (!formData.requirements.trim()) errors.requirements = 'Job requirements are required';
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      // Scroll to the first error
      const firstErrorField = Object.keys(formErrors)[0];
      if (firstErrorField) {
        const element = document.getElementById(firstErrorField);
        if (element) element.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    
    setIsSubmitting(true);
    
    // In a real app, this would submit to a backend
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      
      // Redirect after a short delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    }, 1000);
  };

  const categories = [
    { id: 'cook', label: t('home.categories.cook') },
    { id: 'waiter', label: t('home.categories.waiter') },
    { id: 'bartender', label: t('home.categories.bartender') },
    { id: 'housekeeper', label: t('home.categories.housekeeper') },
    { id: 'receptionist', label: t('home.categories.receptionist') },
    { id: 'hostess', label: t('home.categories.hostess') },
  ];

  const jobTypes = [
    { id: 'fullTime', label: t('jobs.filters.fullTime') },
    { id: 'partTime', label: t('jobs.filters.partTime') },
    { id: 'temporary', label: t('jobs.filters.temporary') },
    { id: 'seasonal', label: t('jobs.filters.seasonal') },
  ];

  if (submitSuccess) {
    return (
      <div className="pt-24 pb-16 min-h-screen bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="w-16 h-16 mx-auto bg-success-100 text-success-600 rounded-full flex items-center justify-center mb-6">
              <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold mb-4">
              {editJobId ? t('employer.jobForm.updateSuccess') : t('employer.jobForm.success')}
            </h1>
            <p className="text-gray-600 mb-6">
              Redirecting you to your dashboard...
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">
            {editJobId ? t('employer.jobForm.editTitle') : t('employer.jobForm.title')}
          </h1>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-4">{t('employer.jobForm.basicInfo')}</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.jobTitle')} <span className="text-error-600">*</span>
                  </label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.jobTitlePlaceholder')}
                    className={`w-full px-3 py-2 border ${formErrors.title ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  />
                  {formErrors.title && (
                    <p className="mt-1 text-sm text-error-600">{formErrors.title}</p>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                      {t('employer.jobForm.category')} <span className="text-error-600">*</span>
                    </label>
                    <select
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border ${formErrors.category ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                    >
                      <option value="">Select category</option>
                      {categories.map(category => (
                        <option key={category.id} value={category.id}>
                          {category.label}
                        </option>
                      ))}
                    </select>
                    {formErrors.category && (
                      <p className="mt-1 text-sm text-error-600">{formErrors.category}</p>
                    )}
                  </div>
                  
                  <div>
                    <label htmlFor="jobType" className="block text-sm font-medium text-gray-700 mb-1">
                      {t('employer.jobForm.jobType')} <span className="text-error-600">*</span>
                    </label>
                    <select
                      id="jobType"
                      name="jobType"
                      value={formData.jobType}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 border ${formErrors.jobType ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                    >
                      <option value="">Select job type</option>
                      {jobTypes.map(type => (
                        <option key={type.id} value={type.id}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                    {formErrors.jobType && (
                      <p className="mt-1 text-sm text-error-600">{formErrors.jobType}</p>
                    )}
                  </div>
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.location')} <span className="text-error-600">*</span>
                  </label>
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.locationPlaceholder')}
                    className={`w-full px-3 py-2 border ${formErrors.location ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  />
                  {formErrors.location && (
                    <p className="mt-1 text-sm text-error-600">{formErrors.location}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="salary" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.salary')} <span className="text-error-600">*</span>
                  </label>
                  <input
                    type="text"
                    id="salary"
                    name="salary"
                    value={formData.salary}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.salaryPlaceholder')}
                    className={`w-full px-3 py-2 border ${formErrors.salary ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  />
                  {formErrors.salary && (
                    <p className="mt-1 text-sm text-error-600">{formErrors.salary}</p>
                  )}
                </div>
              </div>
            </div>
            
            {/* Job Details */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-4">{t('employer.jobForm.details')}</h2>
              
              <div className="space-y-4">
                <div>
                  <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.description')} <span className="text-error-600">*</span>
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={6}
                    value={formData.description}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.descriptionPlaceholder')}
                    className={`w-full px-3 py-2 border ${formErrors.description ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  ></textarea>
                  {formErrors.description && (
                    <p className="mt-1 text-sm text-error-600">{formErrors.description}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="requirements" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.requirements')} <span className="text-error-600">*</span>
                  </label>
                  <textarea
                    id="requirements"
                    name="requirements"
                    rows={4}
                    value={formData.requirements}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.requirementsPlaceholder')}
                    className={`w-full px-3 py-2 border ${formErrors.requirements ? 'border-error-600' : 'border-gray-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
                  ></textarea>
                  <p className="mt-1 text-xs text-gray-500">
                    Enter each requirement on a new line
                  </p>
                  {formErrors.requirements && (
                    <p className="mt-1 text-sm text-error-600">{formErrors.requirements}</p>
                  )}
                </div>
                
                <div>
                  <label htmlFor="benefits" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('employer.jobForm.benefits')}
                  </label>
                  <textarea
                    id="benefits"
                    name="benefits"
                    rows={4}
                    value={formData.benefits}
                    onChange={handleChange}
                    placeholder={t('employer.jobForm.benefitsPlaceholder')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  ></textarea>
                  <p className="mt-1 text-xs text-gray-500">
                    Enter each benefit on a new line
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting}
                className="bg-primary-800 hover:bg-primary-700 text-white py-2 px-6 rounded-md font-medium transition-colors disabled:opacity-70"
              >
                {isSubmitting ? (
                  <svg className="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : editJobId ? (
                  t('employer.jobForm.update')
                ) : (
                  t('employer.jobForm.submit')
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default PostJobPage;