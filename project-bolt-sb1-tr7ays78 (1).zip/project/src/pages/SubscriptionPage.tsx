import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Crown, Check, CreditCard } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';

const SubscriptionPage = () => {
  const { t } = useTranslation();
  const { isVip, setVipStatus } = useAuthStore();
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [subscriptionSuccess, setSubscriptionSuccess] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'VIP Subscription | JobNest';
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      setProcessing(false);
      setVipStatus(true);
      setSubscriptionSuccess(true);
    }, 1500);
  };

  const handleCancelSubscription = () => {
    const confirm = window.confirm('Are you sure you want to cancel your VIP subscription?');
    if (confirm) {
      setVipStatus(false);
    }
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6">{t('worker.subscription.title')}</h1>

        {subscriptionSuccess ? (
          <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="w-16 h-16 mx-auto bg-success-100 text-success-600 rounded-full flex items-center justify-center mb-6">
              <Crown className="h-8 w-8" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Subscription Successful!</h2>
            <p className="text-gray-600 mb-6">
              Your account has been upgraded to VIP status. Enjoy all the premium features!
            </p>
            <button
              onClick={() => setSubscriptionSuccess(false)}
              className="bg-primary-800 hover:bg-primary-700 text-white py-2 px-6 rounded-md font-medium transition-colors"
            >
              Continue
            </button>
          </div>
        ) : (
          <div className="max-w-4xl mx-auto">
            {/* Current Plan */}
            <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
              <h2 className="text-lg font-semibold mb-4">{t('worker.subscription.current')}</h2>
              <div className="flex items-center">
                <div className={`rounded-full p-3 mr-4 ${isVip ? 'bg-secondary-100' : 'bg-gray-100'}`}>
                  <Crown className={`h-6 w-6 ${isVip ? 'text-secondary-600' : 'text-gray-400'}`} />
                </div>
                <div>
                  <p className="font-medium">
                    {isVip ? t('worker.subscription.vip') : t('worker.subscription.free')}
                  </p>
                  {isVip && (
                    <p className="text-sm text-gray-500">
                      €10/month • Next billing date: April 15, 2025
                    </p>
                  )}
                </div>
                {isVip && (
                  <button
                    onClick={handleCancelSubscription}
                    className="ml-auto text-sm text-gray-500 hover:text-gray-700"
                  >
                    Cancel subscription
                  </button>
                )}
              </div>
            </div>

            {!isVip && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Free Plan */}
                <div className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold">{t('worker.subscription.free')}</h2>
                    <p className="text-3xl font-bold mt-2">€0</p>
                    <p className="text-gray-500">forever</p>
                  </div>

                  <ul className="space-y-3 mb-6">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                      <span>Basic job search</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                      <span>Job applications</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                      <span>Save favorite jobs</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-gray-400 mt-0.5 mr-2 flex-shrink-0" />
                      <span>Basic profile</span>
                    </li>
                  </ul>

                  <button
                    disabled
                    className="w-full bg-gray-100 text-gray-800 py-2 px-4 rounded-md font-medium cursor-default"
                  >
                    Current Plan
                  </button>
                </div>

                {/* VIP Plan */}
                <div className="bg-primary-50 p-6 rounded-lg shadow-sm border-2 border-primary-200 relative">
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-secondary-500 text-white px-4 py-1 rounded-full text-sm font-medium">
                    Recommended
                  </div>

                  <div className="text-center mb-6">
                    <h2 className="text-xl font-bold text-primary-800">{t('worker.subscription.vip')}</h2>
                    <p className="text-3xl font-bold mt-2">{t('worker.subscription.price')}</p>
                    <p className="text-gray-600">cancel anytime</p>
                  </div>

                  <ul className="space-y-3 mb-6">
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="font-medium text-primary-900">{t('worker.subscription.feature1')}</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="font-medium text-primary-900">{t('worker.subscription.feature2')}</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="font-medium text-primary-900">{t('worker.subscription.feature3')}</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="font-medium text-primary-900">{t('worker.subscription.feature4')}</span>
                    </li>
                    <li className="flex items-start">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5 mr-2 flex-shrink-0" />
                      <span className="font-medium text-primary-900">All free features included</span>
                    </li>
                  </ul>

                  <button
                    onClick={() => setShowPaymentForm(true)}
                    className="w-full bg-primary-800 hover:bg-primary-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
                  >
                    {t('worker.subscription.subscribe')}
                  </button>
                </div>
              </div>
            )}

            {/* Payment Form */}
            {showPaymentForm && (
              <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                <div className="bg-white rounded-lg shadow-lg max-w-md w-full p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-bold">Subscribe to VIP</h2>
                    <button
                      onClick={() => setShowPaymentForm(false)}
                      className="text-gray-500 hover:text-gray-700"
                    >
                      &times;
                    </button>
                  </div>

                  <form onSubmit={handleSubscribe} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Card Number
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          placeholder="1234 5678 9012 3456"
                          className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        />
                        <CreditCard className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Expiration Date
                        </label>
                        <input
                          type="text"
                          placeholder="MM/YY"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          CVC
                        </label>
                        <input
                          type="text"
                          placeholder="123"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Cardholder Name
                      </label>
                      <input
                        type="text"
                        placeholder="John Doe"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                      />
                    </div>

                    <div className="pt-4">
                      <button
                        type="submit"
                        disabled={processing}
                        className="w-full bg-primary-800 hover:bg-primary-700 text-white py-3 px-4 rounded-md font-medium transition-colors disabled:opacity-70"
                      >
                        {processing ? (
                          <svg className="animate-spin h-5 w-5 text-white mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                        ) : (
                          'Pay €10 and Subscribe'
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-gray-500 text-center mt-4">
                      You'll be charged €10 now and then €10 monthly until you cancel.
                    </p>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SubscriptionPage;