import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';
import { Search, ArrowRight, ChefHat, Utensils, Wine, Bed, User, Coffee } from 'lucide-react';
import JobCard from '../components/jobs/JobCard';
import { useJobStore } from '../stores/jobStore';
import { useAuthStore } from '../stores/authStore';

const HomePage = () => {
  const { t } = useTranslation();
  const { jobs } = useJobStore();
  const { isAuthenticated, userType } = useAuthStore();

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'JobNest | Connect Hospitality Workers & Employers';
  }, []);

  const featuredJobs = jobs.filter(job => job.featured).slice(0, 3);

  const categories = [
    { icon: <ChefHat className="h-8 w-8" />, name: t('home.categories.cook'), id: 'cook' },
    { icon: <Utensils className="h-8 w-8" />, name: t('home.categories.waiter'), id: 'waiter' },
    { icon: <Wine className="h-8 w-8" />, name: t('home.categories.bartender'), id: 'bartender' },
    { icon: <Bed className="h-8 w-8" />, name: t('home.categories.housekeeper'), id: 'housekeeper' },
    { icon: <User className="h-8 w-8" />, name: t('home.categories.receptionist'), id: 'receptionist' },
    { icon: <Coffee className="h-8 w-8" />, name: t('home.categories.hostess'), id: 'hostess' },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary-900 via-primary-800 to-primary-700 text-white pt-32 pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=1920')] opacity-10 bg-cover bg-center"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-primary-900/90 to-primary-800/90"></div>
        
        <div className="container mx-auto px-4 relative">
          <div className="max-w-3xl mx-auto text-center">
            <span className="inline-block px-4 py-1 bg-white/10 backdrop-blur-sm rounded-full text-sm font-medium mb-6">
              #1 Hospitality Job Platform in the Balkans
            </span>
            
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80">
              {t('home.hero.title')}
            </h1>
            
            <p className="text-xl mb-8 text-primary-100">
              {t('home.hero.subtitle')}
            </p>
            
            <div className="relative max-w-2xl mx-auto">
              <div className="flex items-center bg-white/10 backdrop-blur-md rounded-2xl overflow-hidden p-2">
                <div className="flex-grow">
                  <input
                    type="text"
                    placeholder={t('jobs.searchPlaceholder')}
                    className="w-full px-6 py-4 bg-transparent text-white placeholder-white/60 focus:outline-none"
                  />
                </div>
                <Link 
                  to="/jobs" 
                  className="bg-white text-primary-800 py-4 px-8 rounded-xl font-medium transition-all hover:bg-primary-50 hover:scale-105 flex items-center shadow-lg"
                >
                  <Search className="h-5 w-5 mr-2" />
                  {t('common.search')}
                </Link>
              </div>
            </div>

            <div className="mt-8 text-primary-100">
              <span className="text-white/80 font-medium">{t('jobs.filters.categories')}:</span>
              <div className="flex flex-wrap justify-center gap-3 mt-3">
                {categories.slice(0, 4).map((category) => (
                  <Link 
                    key={category.id}
                    to={`/jobs?category=${category.id}`}
                    className="inline-flex items-center px-4 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white rounded-xl transition-all hover:scale-105"
                  >
                    {category.icon}
                    <span className="ml-2">{category.name}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-b from-transparent to-gray-50"></div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">
            {t('home.categories.title')}
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {categories.map((category) => (
              <Link 
                key={category.id}
                to={`/jobs?category=${category.id}`}
                className="flex flex-col items-center p-6 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors text-center"
              >
                <div className="flex items-center justify-center w-16 h-16 bg-primary-100 text-primary-800 rounded-full mb-4">
                  {category.icon}
                </div>
                <span className="font-medium">{category.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Jobs Section */}
      {featuredJobs.length > 0 && (
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-bold">
                {t('home.featured.title')}
              </h2>
              <Link 
                to="/jobs"
                className="flex items-center text-primary-800 hover:text-primary-700 font-medium"
              >
                {t('home.featured.viewAll')}
                <ArrowRight className="h-5 w-5 ml-2" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredJobs.map((job) => (
                <JobCard key={job.id} job={job} featured />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* For Employers & Workers */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* For Employers */}
            <div className="bg-primary-50 rounded-xl p-8 md:p-10">
              <h3 className="text-2xl font-bold text-primary-800 mb-4">
                {t('home.employers.title')}
              </h3>
              <p className="text-neutral-700 mb-6">
                {t('home.employers.subtitle')}
              </p>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-primary-800 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Access a pool of qualified hospitality professionals</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-primary-800 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Post jobs and receive applications within hours</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-primary-800 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Manage all candidates from your dashboard</span>
                </li>
              </ul>
              
              <Link 
                to={isAuthenticated && userType === 'employer' ? '/post-job' : '/register'}
                className="inline-block bg-primary-800 hover:bg-primary-700 text-white py-3 px-6 rounded-md font-medium transition-colors"
              >
                {t('home.employers.cta')}
              </Link>
            </div>
            
            {/* For Workers */}
            <div className="bg-secondary-50 rounded-xl p-8 md:p-10">
              <h3 className="text-2xl font-bold text-secondary-700 mb-4">
                {t('home.workers.title')}
              </h3>
              <p className="text-neutral-700 mb-6">
                {t('home.workers.subtitle')}
              </p>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-secondary-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Find jobs matching your skills and experience</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-secondary-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Apply with just a few clicks</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-secondary-600 mt-0.5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span>Upgrade to VIP for premium features</span>
                </li>
              </ul>
              
              <Link 
                to={isAuthenticated && userType === 'worker' ? '/profile' : '/register'}
                className="inline-block bg-secondary-600 hover:bg-secondary-700 text-white py-3 px-6 rounded-md font-medium transition-colors"
              >
                {t('home.workers.cta')}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;