import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Heart } from 'lucide-react';
import JobCard from '../components/jobs/JobCard';
import { useJobStore } from '../stores/jobStore';

const FavoritesPage = () => {
  const { t } = useTranslation();
  const { jobs, favorites } = useJobStore();
  
  const favoriteJobs = jobs.filter(job => favorites.includes(job.id));
  
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Saved Jobs | JobNest';
  }, []);

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        <h1 className="text-2xl font-bold mb-6">{t('worker.favorites.title')}</h1>
        
        {favoriteJobs.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {favoriteJobs.map(job => (
              <JobCard key={job.id} job={job} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-8 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
              <Heart className="h-8 w-8 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold mb-2">{t('worker.favorites.emptyState')}</h2>
            <p className="text-gray-500 mb-6">
              Save jobs you're interested in by clicking the heart icon.
            </p>
            <Link
              to="/jobs"
              className="inline-block bg-primary-800 hover:bg-primary-700 text-white py-2 px-6 rounded-md font-medium transition-colors"
            >
              {t('worker.favorites.browseCta')}
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;