import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useSearchParams } from 'react-router-dom';
import { Filter, Search, X } from 'lucide-react';
import JobCard from '../components/jobs/JobCard';
import { useJobStore, Job } from '../stores/jobStore';

const JobsPage = () => {
  const { t } = useTranslation();
  const { jobs, filters, setFilter, clearFilters } = useJobStore();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);

  // Set initial filters from URL params
  useEffect(() => {
    const category = searchParams.get('category');
    const location = searchParams.get('location');
    const jobType = searchParams.get('jobType');
    const search = searchParams.get('search');

    if (category) setFilter('category', category);
    if (location) setFilter('location', location);
    if (jobType) setFilter('jobType', jobType);
    if (search) setFilter('search', search);
  }, []);

  // Update filtered jobs when filters change
  useEffect(() => {
    let result = [...jobs];

    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        job =>
          job.title.toLowerCase().includes(searchLower) ||
          job.company.toLowerCase().includes(searchLower) ||
          job.location.toLowerCase().includes(searchLower) ||
          job.description.toLowerCase().includes(searchLower)
      );
    }

    if (filters.category) {
      result = result.filter(job => job.category === filters.category);
    }

    if (filters.location) {
      result = result.filter(job =>
        job.location.toLowerCase().includes(filters.location!.toLowerCase())
      );
    }

    if (filters.jobType) {
      result = result.filter(job => job.jobType === filters.jobType);
    }

    setFilteredJobs(result);

    // Update URL params
    const params: Record<string, string> = {};
    if (filters.search) params.search = filters.search;
    if (filters.category) params.category = filters.category;
    if (filters.location) params.location = filters.location;
    if (filters.jobType) params.jobType = filters.jobType;

    setSearchParams(params, { replace: true });
  }, [filters, jobs]);

  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Browse Jobs | JobNest';
  }, []);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilter('search', e.target.value);
  };

  const handleCategoryFilter = (category: string) => {
    setFilter('category', filters.category === category ? null : category);
  };

  const handleJobTypeFilter = (jobType: string) => {
    setFilter('jobType', filters.jobType === jobType ? null : jobType);
  };

  const handleClearFilters = () => {
    clearFilters();
  };

  const categories = [
    { id: 'cook', label: t('home.categories.cook') },
    { id: 'waiter', label: t('home.categories.waiter') },
    { id: 'bartender', label: t('home.categories.bartender') },
    { id: 'housekeeper', label: t('home.categories.housekeeper') },
    { id: 'receptionist', label: t('home.categories.receptionist') },
    { id: 'hostess', label: t('home.categories.hostess') },
  ];

  const jobTypes = [
    { id: 'fullTime', label: t('jobs.filters.fullTime') },
    { id: 'partTime', label: t('jobs.filters.partTime') },
    { id: 'temporary', label: t('jobs.filters.temporary') },
    { id: 'seasonal', label: t('jobs.filters.seasonal') },
  ];

  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters - Desktop */}
          <div className="hidden md:block w-72 bg-white p-6 rounded-lg shadow-sm sticky top-24 h-fit">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-semibold text-lg">{t('jobs.filters.title')}</h3>
              {(filters.category || filters.location || filters.jobType || filters.search) && (
                <button
                  onClick={handleClearFilters}
                  className="text-sm text-primary-700 hover:text-primary-800 flex items-center"
                >
                  <X className="h-4 w-4 mr-1" />
                  {t('jobs.filters.clear')}
                </button>
              )}
            </div>

            {/* Categories */}
            <div className="mb-6">
              <h4 className="font-medium text-neutral-800 mb-3">{t('jobs.filters.categories')}</h4>
              <div className="space-y-2">
                {categories.map(category => (
                  <div key={category.id} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`category-${category.id}`}
                      checked={filters.category === category.id}
                      onChange={() => handleCategoryFilter(category.id)}
                      className="h-4 w-4 text-primary-800 focus:ring-primary-700 border-gray-300 rounded"
                    />
                    <label htmlFor={`category-${category.id}`} className="ml-2 text-sm text-gray-700">
                      {category.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Job Type */}
            <div className="mb-6">
              <h4 className="font-medium text-neutral-800 mb-3">{t('jobs.filters.jobType')}</h4>
              <div className="space-y-2">
                {jobTypes.map(type => (
                  <div key={type.id} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`jobType-${type.id}`}
                      checked={filters.jobType === type.id}
                      onChange={() => handleJobTypeFilter(type.id)}
                      className="h-4 w-4 text-primary-800 focus:ring-primary-700 border-gray-300 rounded"
                    />
                    <label htmlFor={`jobType-${type.id}`} className="ml-2 text-sm text-gray-700">
                      {type.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {/* Location - Simple input for demo */}
            <div className="mb-6">
              <h4 className="font-medium text-neutral-800 mb-3">{t('jobs.filters.location')}</h4>
              <input
                type="text"
                placeholder="Enter location"
                value={filters.location || ''}
                onChange={(e) => setFilter('location', e.target.value || null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 text-sm"
              />
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Search and Filter Toggle */}
            <div className="bg-white p-4 rounded-lg shadow-sm mb-6">
              <div className="flex items-center">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    placeholder={t('jobs.searchPlaceholder')}
                    value={filters.search || ''}
                    onChange={handleSearchChange}
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                  />
                </div>
                <button
                  onClick={toggleFilters}
                  className="ml-4 md:hidden bg-white p-2 rounded-md border border-gray-300 hover:bg-gray-50"
                >
                  <Filter className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              {/* Mobile Filters */}
              {showFilters && (
                <div className="md:hidden mt-4 pt-4 border-t">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-semibold">{t('jobs.filters.title')}</h3>
                    {(filters.category || filters.location || filters.jobType || filters.search) && (
                      <button
                        onClick={handleClearFilters}
                        className="text-sm text-primary-700 hover:text-primary-800 flex items-center"
                      >
                        <X className="h-4 w-4 mr-1" />
                        {t('jobs.filters.clear')}
                      </button>
                    )}
                  </div>

                  {/* Categories */}
                  <div className="mb-4">
                    <h4 className="font-medium text-neutral-800 mb-2 text-sm">{t('jobs.filters.categories')}</h4>
                    <div className="flex flex-wrap gap-2">
                      {categories.map(category => (
                        <button
                          key={category.id}
                          onClick={() => handleCategoryFilter(category.id)}
                          className={`py-1 px-3 text-xs rounded-full ${
                            filters.category === category.id
                              ? 'bg-primary-100 text-primary-800 border border-primary-300'
                              : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
                          }`}
                        >
                          {category.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Job Types */}
                  <div className="mb-4">
                    <h4 className="font-medium text-neutral-800 mb-2 text-sm">{t('jobs.filters.jobType')}</h4>
                    <div className="flex flex-wrap gap-2">
                      {jobTypes.map(type => (
                        <button
                          key={type.id}
                          onClick={() => handleJobTypeFilter(type.id)}
                          className={`py-1 px-3 text-xs rounded-full ${
                            filters.jobType === type.id
                              ? 'bg-primary-100 text-primary-800 border border-primary-300'
                              : 'bg-gray-100 text-gray-800 border border-gray-200 hover:bg-gray-200'
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Location */}
                  <div className="mb-4">
                    <h4 className="font-medium text-neutral-800 mb-2 text-sm">{t('jobs.filters.location')}</h4>
                    <input
                      type="text"
                      placeholder="Enter location"
                      value={filters.location || ''}
                      onChange={(e) => setFilter('location', e.target.value || null)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 text-sm"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      onClick={toggleFilters}
                      className="text-sm text-gray-500 hover:text-gray-700"
                    >
                      Close
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Jobs List */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold text-gray-900">
                  {filteredJobs.length} {filteredJobs.length === 1 ? 'Job' : 'Jobs'} Found
                </h2>
              </div>

              {filteredJobs.length > 0 ? (
                <div className="grid grid-cols-1 gap-4">
                  {filteredJobs.map(job => (
                    <JobCard key={job.id} job={job} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 bg-white rounded-lg shadow-sm">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">{t('jobs.emptyState.title')}</h3>
                  <p className="text-gray-500">{t('jobs.emptyState.description')}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobsPage;