import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { PlusCircle, Eye, Users, Briefcase, Calendar, MapPin, Edit, Trash, ExternalLink, Search } from 'lucide-react';
import { useAuthStore } from '../stores/authStore';
import { useJobStore, Job } from '../stores/jobStore';

const EmployerDashboardPage = () => {
  const { t } = useTranslation();
  const { user } = useAuthStore();
  const { jobs } = useJobStore();
  const [activeTab, setActiveTab] = useState<'jobs' | 'applicants'>('jobs');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter jobs posted by this employer
  const employerJobs = jobs.filter(job => job.employerId === user?.id);
  
  // Mock applicants data for demo
  const mockApplicants = [
    {
      id: 'app-1',
      jobId: employerJobs[0]?.id,
      name: 'John Smith',
      email: 'john.smith@example.com',
      phone: '+381 61 123 4567',
      appliedDate: '2025-03-18',
      status: 'pending',
    },
    {
      id: 'app-2',
      jobId: employerJobs[0]?.id,
      name: 'Ana Petrović',
      email: 'ana.petrovic@example.com',
      phone: '+381 62 345 6789',
      appliedDate: '2025-03-17',
      status: 'reviewing',
    },
    {
      id: 'app-3',
      jobId: employerJobs[0]?.id,
      name: 'Milan Jovanović',
      email: 'milan.j@example.com',
      phone: '+381 63 456 7890',
      appliedDate: '2025-03-16',
      status: 'interviewed',
    },
  ];
  
  const [applicants, setApplicants] = useState(mockApplicants);
  
  const filteredJobs = employerJobs.filter(job => 
    job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    job.location.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredApplicants = applicants.filter(applicant => 
    applicant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    applicant.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  useEffect(() => {
    window.scrollTo(0, 0);
    document.title = 'Employer Dashboard | JobNest';
  }, []);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };
  
  const handleApplicantStatusChange = (applicantId: string, newStatus: string) => {
    setApplicants(applicants.map(app => 
      app.id === applicantId ? { ...app, status: newStatus } : app
    ));
  };
  
  const handleDeleteJob = (jobId: string) => {
    // In a real app, this would delete the job
    alert(`Job deleted: ${jobId}`);
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
          <h1 className="text-2xl font-bold">{t('employer.dashboard.title')}</h1>
          <Link
            to="/post-job"
            className="inline-flex items-center bg-primary-800 hover:bg-primary-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
          >
            <PlusCircle className="h-5 w-5 mr-2" />
            {t('nav.postJob')}
          </Link>
        </div>
        
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="rounded-full bg-primary-100 p-3 mr-4">
                <Briefcase className="h-6 w-6 text-primary-800" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">{t('employer.dashboard.stats.activeJobs')}</p>
                <p className="text-2xl font-bold">{employerJobs.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="rounded-full bg-secondary-100 p-3 mr-4">
                <Users className="h-6 w-6 text-secondary-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">{t('employer.dashboard.stats.applications')}</p>
                <p className="text-2xl font-bold">{applicants.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm">
            <div className="flex items-center">
              <div className="rounded-full bg-green-100 p-3 mr-4">
                <Eye className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-gray-500 text-sm">{t('employer.dashboard.stats.views')}</p>
                <p className="text-2xl font-bold">254</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-8">
          <div className="flex border-b">
            <button
              className={`flex-1 py-4 px-6 text-center font-medium ${
                activeTab === 'jobs'
                  ? 'text-primary-800 border-b-2 border-primary-800'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveTab('jobs')}
            >
              {t('employer.dashboard.jobsTab')}
            </button>
            <button
              className={`flex-1 py-4 px-6 text-center font-medium ${
                activeTab === 'applicants'
                  ? 'text-primary-800 border-b-2 border-primary-800'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
              onClick={() => setActiveTab('applicants')}
            >
              {t('employer.dashboard.applicantsTab')}
            </button>
          </div>
          
          {/* Search */}
          <div className="p-4 border-b">
            <div className="relative">
              <input
                type="text"
                placeholder={`Search ${activeTab === 'jobs' ? 'jobs' : 'applicants'}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
          </div>
          
          {/* Tab Content */}
          <div className="p-4">
            {activeTab === 'jobs' && (
              <>
                {filteredJobs.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Job Title
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Location
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Posted Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Applications
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredJobs.map((job) => (
                          <tr key={job.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4">
                              <div className="text-sm font-medium text-gray-900">{job.title}</div>
                              <div className="text-sm text-gray-500">{job.jobType}</div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center text-sm text-gray-500">
                                <MapPin className="h-4 w-4 mr-1" />
                                {job.location}
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center text-sm text-gray-500">
                                <Calendar className="h-4 w-4 mr-1" />
                                {formatDate(job.postedDate)}
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="text-sm text-gray-900">
                                {applicants.filter(app => app.jobId === job.id).length}
                              </div>
                            </td>
                            <td className="px-6 py-4 text-right text-sm font-medium whitespace-nowrap">
                              <div className="flex justify-end space-x-2">
                                <Link
                                  to={`/jobs/${job.id}`}
                                  className="text-gray-500 hover:text-gray-700"
                                  title="View"
                                >
                                  <ExternalLink className="h-5 w-5" />
                                </Link>
                                <Link
                                  to={`/post-job?edit=${job.id}`}
                                  className="text-primary-600 hover:text-primary-800"
                                  title="Edit"
                                >
                                  <Edit className="h-5 w-5" />
                                </Link>
                                <button
                                  onClick={() => handleDeleteJob(job.id)}
                                  className="text-error-600 hover:text-error-800"
                                  title="Delete"
                                >
                                  <Trash className="h-5 w-5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                      <Briefcase className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {t('employer.dashboard.noJobs')}
                    </h3>
                    <Link
                      to="/post-job"
                      className="inline-block mt-3 bg-primary-800 hover:bg-primary-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
                    >
                      {t('employer.dashboard.postJobCta')}
                    </Link>
                  </div>
                )}
              </>
            )}
            
            {activeTab === 'applicants' && (
              <>
                {filteredApplicants.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead>
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Applicant
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Job Applied For
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Application Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredApplicants.map((applicant) => {
                          const job = employerJobs.find(j => j.id === applicant.jobId);
                          
                          return (
                            <tr key={applicant.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4">
                                <div className="flex items-center">
                                  <div className="flex-shrink-0 h-10 w-10 bg-gray-200 rounded-full flex items-center justify-center">
                                    <span className="text-gray-600 font-medium">
                                      {applicant.name.charAt(0)}
                                    </span>
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-gray-900">{applicant.name}</div>
                                    <div className="text-sm text-gray-500">{applicant.email}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm text-gray-900">{job?.title}</div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm text-gray-500">{formatDate(applicant.appliedDate)}</div>
                              </td>
                              <td className="px-6 py-4">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  applicant.status === 'pending' 
                                    ? 'bg-yellow-100 text-yellow-800' 
                                    : applicant.status === 'reviewing'
                                    ? 'bg-blue-100 text-blue-800'
                                    : applicant.status === 'interviewed'
                                    ? 'bg-purple-100 text-purple-800'
                                    : applicant.status === 'accepted'
                                    ? 'bg-green-100 text-green-800'
                                    : 'bg-red-100 text-red-800'
                                }`}>
                                  {t(`employer.applicants.${applicant.status}`)}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right text-sm font-medium whitespace-nowrap">
                                <div className="flex justify-end space-x-2">
                                  <button
                                    className="text-gray-600 hover:text-gray-900"
                                    title={t('employer.applicants.viewResume')}
                                  >
                                    <ExternalLink className="h-5 w-5" />
                                  </button>
                                  <div className="relative group">
                                    <button
                                      className="text-primary-600 hover:text-primary-800"
                                      title={t('employer.applicants.updateStatus')}
                                    >
                                      <Edit className="h-5 w-5" />
                                    </button>
                                    <div className="absolute right-0 w-36 bg-white shadow-lg rounded-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-10">
                                      <div className="py-1">
                                        <button
                                          onClick={() => handleApplicantStatusChange(applicant.id, 'pending')}
                                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                        >
                                          {t('employer.applicants.pending')}
                                        </button>
                                        <button
                                          onClick={() => handleApplicantStatusChange(applicant.id, 'reviewing')}
                                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                        >
                                          {t('employer.applicants.reviewing')}
                                        </button>
                                        <button
                                          onClick={() => handleApplicantStatusChange(applicant.id, 'interviewed')}
                                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                        >
                                          {t('employer.applicants.interviewed')}
                                        </button>
                                        <button
                                          onClick={() => handleApplicantStatusChange(applicant.id, 'accepted')}
                                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                        >
                                          {t('employer.applicants.accepted')}
                                        </button>
                                        <button
                                          onClick={() => handleApplicantStatusChange(applicant.id, 'rejected')}
                                          className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                                        >
                                          {t('employer.applicants.rejected')}
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                      <Users className="h-8 w-8 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {t('employer.applicants.noApplicants')}
                    </h3>
                    <p className="text-gray-500">
                      When someone applies to your job, they'll appear here.
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployerDashboardPage;