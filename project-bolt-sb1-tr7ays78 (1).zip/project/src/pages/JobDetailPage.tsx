import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Heart, Share2, MapPin, Calendar, DollarSign, Clock, Building, ChevronLeft } from 'lucide-react';
import { useJobStore, Job } from '../stores/jobStore';
import { useAuthStore } from '../stores/authStore';
import JobCard from '../components/jobs/JobCard';
import LoadingSpinner from '../components/common/LoadingSpinner';

const JobDetailPage = () => {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { jobs, favorites, addFavorite, removeFavorite } = useJobStore();
  const { isAuthenticated, userType } = useAuthStore();
  const [job, setJob] = useState<Job | null>(null);
  const [similarJobs, setSimilarJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [applicationSubmitted, setApplicationSubmitted] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    
    // Find the job
    const foundJob = jobs.find(j => j.id === id);
    if (foundJob) {
      setJob(foundJob);
      document.title = `${foundJob.title} at ${foundJob.company} | JobNest`;
      
      // Find similar jobs (same category, excluding this one)
      const similar = jobs
        .filter(j => j.category === foundJob.category && j.id !== foundJob.id)
        .slice(0, 3);
      setSimilarJobs(similar);
    } else {
      navigate('/jobs', { replace: true });
    }
    
    setLoading(false);
  }, [id, jobs, navigate]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  const handleFavoriteToggle = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (job) {
      if (favorites.includes(job.id)) {
        removeFavorite(job.id);
      } else {
        addFavorite(job.id);
      }
    }
  };

  const handleApplyClick = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (userType !== 'worker') {
      alert('Only workers can apply for jobs.');
      return;
    }
    
    setShowApplicationForm(true);
  };

  const handleShareClick = () => {
    if (navigator.share) {
      navigator.share({
        title: `${job?.title} at ${job?.company}`,
        text: `Check out this job: ${job?.title} at ${job?.company}`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleSubmitApplication = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would submit to a backend
    setApplicationSubmitted(true);
  };

  if (loading) return <LoadingSpinner />;
  if (!job) return null;

  const isFavorite = favorites.includes(job.id);
  const jobTypeMap: Record<string, string> = {
    fullTime: t('jobs.filters.fullTime'),
    partTime: t('jobs.filters.partTime'),
    temporary: t('jobs.filters.temporary'),
    seasonal: t('jobs.filters.seasonal'),
  };

  return (
    <div className="pt-24 pb-16 min-h-screen bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Back button */}
        <Link to="/jobs" className="inline-flex items-center text-primary-800 hover:text-primary-700 mb-6">
          <ChevronLeft className="h-4 w-4 mr-1" />
          {t('common.back')}
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Job Header */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-start gap-4 mb-4">
                {job.companyLogo && (
                  <img 
                    src={job.companyLogo} 
                    alt={job.company} 
                    className="w-16 h-16 object-cover rounded-md"
                  />
                )}
                
                <div className="flex-grow">
                  <h1 className="text-2xl font-bold text-neutral-800 mb-1">
                    {job.title}
                  </h1>
                  <p className="text-neutral-600 mb-2">
                    {job.company}
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <div className="flex items-center text-sm text-neutral-500">
                      <MapPin className="h-4 w-4 mr-1" />
                      {job.location}
                    </div>
                    <div className="flex items-center text-sm text-neutral-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(job.postedDate)}
                    </div>
                    <div className="flex items-center text-sm text-neutral-500">
                      <Clock className="h-4 w-4 mr-1" />
                      {jobTypeMap[job.jobType]}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between border-t pt-4">
                <div className="text-lg font-semibold text-neutral-800">
                  <DollarSign className="h-5 w-5 inline-block text-secondary-600 mr-1" />
                  {job.salary}
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={handleShareClick}
                    className="flex items-center justify-center p-2 text-neutral-500 hover:text-primary-700 rounded-full hover:bg-gray-100"
                    aria-label="Share"
                  >
                    <Share2 className="h-5 w-5" />
                  </button>
                  
                  <button
                    onClick={handleFavoriteToggle}
                    className={`flex items-center justify-center p-2 rounded-full hover:bg-gray-100 ${
                      isFavorite ? 'text-secondary-500 hover:text-secondary-700' : 'text-neutral-500 hover:text-secondary-500'
                    }`}
                    aria-label={isFavorite ? t('jobs.detail.savedButton') : t('jobs.detail.saveButton')}
                  >
                    <Heart className="h-5 w-5" fill={isFavorite ? 'currentColor' : 'none'} />
                  </button>
                </div>
              </div>
            </div>

            {/* Job Description */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">{t('jobs.detail.description')}</h2>
              <div className="prose max-w-none text-neutral-700">
                <p>{job.description}</p>
              </div>
            </div>

            {/* Job Requirements */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">{t('jobs.detail.requirements')}</h2>
              <ul className="list-disc list-inside space-y-2 text-neutral-700">
                {job.requirements.map((req, index) => (
                  <li key={index}>{req}</li>
                ))}
              </ul>
            </div>

            {/* Job Benefits */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">{t('jobs.detail.benefits')}</h2>
              <ul className="list-disc list-inside space-y-2 text-neutral-700">
                {job.benefits.map((benefit, index) => (
                  <li key={index}>{benefit}</li>
                ))}
              </ul>
            </div>

            {/* About Company */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">{t('jobs.detail.aboutEmployer')}</h2>
              <div className="flex items-start gap-4">
                {job.companyLogo && (
                  <img 
                    src={job.companyLogo} 
                    alt={job.company} 
                    className="w-12 h-12 object-cover rounded-md"
                  />
                )}
                <div>
                  <h3 className="font-medium text-lg">{job.company}</h3>
                  <p className="text-neutral-600">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla facilisi. 
                    Sed euismod, eros vel aliquam faucibus, velit nunc ultrices velit, 
                    eget tincidunt nisl nunc vel eros.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Application Button */}
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              {applicationSubmitted ? (
                <div className="text-center py-4">
                  <div className="w-16 h-16 bg-success-100 text-success-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{t('jobs.application.success')}</h3>
                  <p className="text-neutral-600 mb-4">
                    Your application has been submitted. The employer will contact you if they're interested.
                  </p>
                  <Link
                    to="/jobs"
                    className="inline-block bg-primary-100 hover:bg-primary-200 text-primary-800 py-2 px-4 rounded-md font-medium transition-colors"
                  >
                    Browse More Jobs
                  </Link>
                </div>
              ) : showApplicationForm ? (
                <div>
                  <h3 className="text-xl font-semibold mb-4">
                    {t('jobs.application.title')} {job.title}
                  </h3>
                  <form onSubmit={handleSubmitApplication} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {t('jobs.application.coverLetter')}
                      </label>
                      <textarea
                        rows={5}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        placeholder={t('jobs.application.coverLetterPlaceholder')}
                        required
                      ></textarea>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        {t('jobs.application.cvUpload')}
                      </label>
                      <input
                        type="file"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                        accept=".pdf,.doc,.docx"
                        required
                      />
                    </div>
                    <div className="flex space-x-3">
                      <button
                        type="button"
                        onClick={() => setShowApplicationForm(false)}
                        className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-800 py-2 px-4 rounded-md font-medium transition-colors"
                      >
                        {t('common.cancel')}
                      </button>
                      <button
                        type="submit"
                        className="flex-1 bg-primary-800 hover:bg-primary-700 text-white py-2 px-4 rounded-md font-medium transition-colors"
                      >
                        {t('jobs.application.submit')}
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="text-center">
                  <h3 className="text-xl font-semibold mb-4">
                    Interested in this job?
                  </h3>
                  <button
                    onClick={handleApplyClick}
                    className="w-full bg-primary-800 hover:bg-primary-700 text-white py-3 px-4 rounded-md font-medium transition-colors mb-3"
                  >
                    {t('jobs.detail.applyButton')}
                  </button>
                  <button
                    onClick={handleFavoriteToggle}
                    className={`w-full py-3 px-4 rounded-md font-medium transition-colors border ${
                      isFavorite
                        ? 'bg-secondary-50 text-secondary-700 border-secondary-200'
                        : 'bg-white text-neutral-700 border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    <Heart className="h-5 w-5 inline-block mr-2" fill={isFavorite ? 'currentColor' : 'none'} />
                    {isFavorite ? t('jobs.detail.savedButton') : t('jobs.detail.saveButton')}
                  </button>
                </div>
              )}
            </div>

            {/* Similar Jobs */}
            {similarJobs.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4">{t('jobs.detail.similarJobs')}</h3>
                <div className="space-y-4">
                  {similarJobs.map((similarJob) => (
                    <div key={similarJob.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                      <Link to={`/jobs/${similarJob.id}`} className="block hover:bg-gray-50 -m-2 p-2 rounded-md">
                        <h4 className="font-medium text-neutral-800">{similarJob.title}</h4>
                        <p className="text-sm text-neutral-600">{similarJob.company}</p>
                        <div className="flex items-center text-xs text-neutral-500 mt-1">
                          <MapPin className="h-3 w-3 mr-1" />
                          {similarJob.location}
                        </div>
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetailPage;