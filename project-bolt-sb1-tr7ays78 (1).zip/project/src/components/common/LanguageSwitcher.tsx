import { useState, useRef, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Globe, ChevronDown } from 'lucide-react';

interface LanguageSwitcherProps {
  currentLanguage: string;
  changeLanguage: (lng: string) => void;
}

const LanguageSwitcher = ({ currentLanguage, changeLanguage }: LanguageSwitcherProps) => {
  const { t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const languages = [
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'sr', name: 'Serbian', flag: '🇷🇸' },
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const getCurrentLanguageName = () => {
    const language = languages.find(lang => lang.code === currentLanguage);
    return language ? language.name : 'English';
  };

  const getCurrentLanguageFlag = () => {
    const language = languages.find(lang => lang.code === currentLanguage);
    return language ? language.flag : '🇬🇧';
  };

  return (
    <div className="relative" ref={menuRef}>
      <button
        className="flex items-center space-x-1 p-1.5 rounded-md hover:bg-gray-100 transition-colors"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-base leading-none mr-1">{getCurrentLanguageFlag()}</span>
        <span className="hidden md:block text-sm">{getCurrentLanguageName()}</span>
        <ChevronDown className="h-4 w-4 text-gray-500" />
      </button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 w-36 bg-white rounded-md shadow-lg py-1 z-50 animate-fade-in">
          {languages.map((language) => (
            <button
              key={language.code}
              className={`flex items-center w-full px-4 py-2 text-sm text-left hover:bg-gray-100 ${
                currentLanguage === language.code ? 'text-primary-700 font-medium' : 'text-gray-700'
              }`}
              onClick={() => {
                changeLanguage(language.code);
                setIsOpen(false);
              }}
            >
              <span className="text-base leading-none mr-2">{language.flag}</span>
              <span>{language.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSwitcher;