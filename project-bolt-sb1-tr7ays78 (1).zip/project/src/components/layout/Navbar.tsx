import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuthStore } from '../../stores/authStore';
import { Menu, Briefcase, ChevronDown, User, Heart, LogOut, PanelRight, Plus, Crown } from 'lucide-react';
import LanguageSwitcher from '../common/LanguageSwitcher';

interface NavbarProps {
  scrolled: boolean;
  currentLanguage: string;
  changeLanguage: (lng: string) => void;
}

const Navbar = ({ scrolled, currentLanguage, changeLanguage }: NavbarProps) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAuthenticated, userType, logout } = useAuthStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setUserMenuOpen(false);
    navigate('/login');
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4">
        <nav className="flex items-center justify-between h-20">
          {/* Logo */}
          <Link 
            to="/" 
            className={`flex items-center space-x-2 transition-colors ${
              scrolled ? 'text-primary-800' : 'text-white'
            }`}
          >
            <Briefcase className="h-8 w-8" />
            <span className="text-xl font-bold">JobNest</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link 
              to="/" 
              className={`font-medium transition-colors ${
                scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
              }`}
            >
              {t('nav.home')}
            </Link>
            <Link 
              to="/jobs" 
              className={`font-medium transition-colors ${
                scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
              }`}
            >
              {t('nav.jobs')}
            </Link>
            
            {isAuthenticated && userType === 'worker' && (
              <Link 
                to="/favorites" 
                className={`font-medium transition-colors ${
                  scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                }`}
              >
                {t('nav.favorites')}
              </Link>
            )}
            
            {isAuthenticated && userType === 'employer' && (
              <>
                <Link 
                  to="/dashboard" 
                  className={`font-medium transition-colors ${
                    scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                  }`}
                >
                  {t('nav.dashboard')}
                </Link>
                <Link 
                  to="/post-job" 
                  className={`font-medium transition-colors ${
                    scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                  }`}
                >
                  {t('nav.postJob')}
                </Link>
              </>
            )}
          </div>

          {/* Right Side: Auth/User Menu */}
          <div className="flex items-center space-x-4">
            <LanguageSwitcher 
              currentLanguage={currentLanguage} 
              changeLanguage={changeLanguage} 
            />
            
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className={`flex items-center space-x-1 font-medium transition-colors ${
                    scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                  }`}
                >
                  <User className="h-5 w-5" />
                  <ChevronDown className="h-4 w-4" />
                </button>
                
                {userMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg py-2 z-50 animate-fade-in border border-gray-100">
                    <Link 
                      to="/profile" 
                      className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                      onClick={() => setUserMenuOpen(false)}
                    >
                      <User className="h-4 w-4 mr-2" />
                      {t('nav.profile')}
                    </Link>
                    
                    {userType === 'worker' && (
                      <>
                        <Link 
                          to="/favorites" 
                          className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <Heart className="h-4 w-4 mr-2" />
                          {t('nav.favorites')}
                        </Link>
                        <Link 
                          to="/subscription" 
                          className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <Crown className="h-4 w-4 mr-2" />
                          {t('nav.subscription')}
                        </Link>
                      </>
                    )}
                    
                    {userType === 'employer' && (
                      <>
                        <Link 
                          to="/dashboard" 
                          className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <PanelRight className="h-4 w-4 mr-2" />
                          {t('nav.dashboard')}
                        </Link>
                        <Link 
                          to="/post-job" 
                          className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                          onClick={() => setUserMenuOpen(false)}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          {t('nav.postJob')}
                        </Link>
                      </>
                    )}
                    
                    <button 
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      {t('nav.logout')}
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link
                  to="/login"
                  className={`font-medium transition-colors ${
                    scrolled ? 'text-primary-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                  }`}
                >
                  {t('nav.login')}
                </Link>
                <Link
                  to="/register"
                  className={`py-2 px-4 rounded-xl font-medium transition-all hover:scale-105 ${
                    scrolled 
                      ? 'bg-primary-800 hover:bg-primary-700 text-white' 
                      : 'bg-white text-primary-800 hover:bg-primary-50'
                  }`}
                >
                  {t('nav.register')}
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button
              className={`md:hidden transition-colors ${
                scrolled ? 'text-neutral-800' : 'text-white'
              }`}
              onClick={() => setMenuOpen(!menuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </nav>

        {/* Mobile Navigation */}
        {menuOpen && (
          <div className="md:hidden py-4 animate-slide-down">
            <div className="flex flex-col space-y-4">
              <Link 
                to="/" 
                className={`font-medium transition-colors ${
                  scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                }`}
                onClick={() => setMenuOpen(false)}
              >
                {t('nav.home')}
              </Link>
              <Link 
                to="/jobs" 
                className={`font-medium transition-colors ${
                  scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                }`}
                onClick={() => setMenuOpen(false)}
              >
                {t('nav.jobs')}
              </Link>
              
              {isAuthenticated && userType === 'worker' && (
                <>
                  <Link 
                    to="/favorites" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.favorites')}
                  </Link>
                  <Link 
                    to="/profile" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.profile')}
                  </Link>
                  <Link 
                    to="/subscription" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.subscription')}
                  </Link>
                </>
              )}
              
              {isAuthenticated && userType === 'employer' && (
                <>
                  <Link 
                    to="/dashboard" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.dashboard')}
                  </Link>
                  <Link 
                    to="/post-job" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.postJob')}
                  </Link>
                  <Link 
                    to="/profile" 
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.profile')}
                  </Link>
                </>
              )}
              
              {isAuthenticated ? (
                <button 
                  onClick={handleLogout}
                  className={`font-medium text-left transition-colors ${
                    scrolled ? 'text-neutral-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                  }`}
                >
                  {t('nav.logout')}
                </button>
              ) : (
                <div className="flex flex-col space-y-2">
                  <Link
                    to="/login"
                    className={`font-medium transition-colors ${
                      scrolled ? 'text-primary-800 hover:text-primary-700' : 'text-white/90 hover:text-white'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.login')}
                  </Link>
                  <Link
                    to="/register"
                    className={`py-2 px-4 rounded-xl font-medium transition-all text-center ${
                      scrolled 
                        ? 'bg-primary-800 hover:bg-primary-700 text-white' 
                        : 'bg-white text-primary-800 hover:bg-primary-50'
                    }`}
                    onClick={() => setMenuOpen(false)}
                  >
                    {t('nav.register')}
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;