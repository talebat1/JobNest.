import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Heart, MapPin, Calendar, DollarSign } from 'lucide-react';
import { useJobStore, Job } from '../../stores/jobStore';
import { useAuthStore } from '../../stores/authStore';

interface JobCardProps {
  job: Job;
  featured?: boolean;
}

const JobCard = ({ job, featured = false }: JobCardProps) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { favorites, addFavorite, removeFavorite } = useJobStore();
  const { isAuthenticated } = useAuthStore();

  const isFavorite = favorites.includes(job.id);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(date);
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    
    if (isFavorite) {
      removeFavorite(job.id);
    } else {
      addFavorite(job.id);
    }
  };

  const handleCardClick = () => {
    navigate(`/jobs/${job.id}`);
  };

  return (
    <div 
      className={`bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-5 cursor-pointer relative border ${featured ? 'border-secondary-500' : 'border-transparent'}`}
      onClick={handleCardClick}
    >
      {featured && (
        <div className="absolute top-3 right-3 bg-secondary-500 text-white text-xs px-2 py-1 rounded-full">
          Featured
        </div>
      )}

      <div className="flex items-start">
        {job.companyLogo && (
          <div className="flex-shrink-0 mr-4">
            <img 
              src={job.companyLogo} 
              alt={job.company} 
              className="w-14 h-14 object-cover rounded-md"
            />
          </div>
        )}
        
        <div className="flex-grow">
          <h3 className="text-lg font-semibold text-neutral-800 mb-1">
            {job.title}
          </h3>
          
          <p className="text-neutral-600 text-sm mb-3">
            {job.company}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-3">
            <div className="flex items-center text-xs text-neutral-500">
              <MapPin className="h-3.5 w-3.5 mr-1" />
              {job.location}
            </div>
            <div className="flex items-center text-xs text-neutral-500">
              <DollarSign className="h-3.5 w-3.5 mr-1" />
              {job.salary}
            </div>
            <div className="flex items-center text-xs text-neutral-500">
              <Calendar className="h-3.5 w-3.5 mr-1" />
              {formatDate(job.postedDate)}
            </div>
          </div>
          
          <div className="flex justify-between items-center mt-4">
            <span className="inline-block px-3 py-1 bg-primary-100 text-primary-800 text-xs font-medium rounded-full">
              {t(`home.categories.${job.category}`)}
            </span>

            <button 
              className={`flex items-center justify-center rounded-full p-2 transition-colors ${
                isFavorite 
                  ? 'text-secondary-500 hover:text-secondary-700' 
                  : 'text-neutral-400 hover:text-secondary-500'
              }`}
              onClick={handleFavoriteClick}
              aria-label={isFavorite ? t('jobs.jobCard.savedJob') : t('jobs.jobCard.saveJob')}
            >
              <Heart className="h-5 w-5" fill={isFavorite ? 'currentColor' : 'none'} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobCard;