import { Navigate, Outlet } from 'react-router-dom';
import { useAuthStore } from '../../stores/authStore';

interface AuthGuardProps {
  allowedUserTypes: ('worker' | 'employer')[];
}

const AuthGuard = ({ allowedUserTypes }: AuthGuardProps) => {
  const { isAuthenticated, userType } = useAuthStore();

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  if (userType && !allowedUserTypes.includes(userType)) {
    return <Navigate to="/" />;
  }

  return <Outlet />;
};

export default AuthGuard;