import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type UserType = 'worker' | 'employer' | null;

interface User {
  id: string;
  email: string;
  name: string;
  userType: UserType;
  company?: string;
  phone?: string;
  isVip?: boolean;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  userType: UserType;
  isVip: boolean;
  // Actions
  login: (user: User) => void;
  logout: () => void;
  updateUser: (userData: Partial<User>) => void;
  setVipStatus: (isVip: boolean) => void;
}

// Demo users for testing
const demoWorker: User = {
  id: 'worker-1',
  email: 'worker@example.com',
  name: 'John Doe',
  userType: 'worker',
  phone: '+381 61 234 5678',
  isVip: false,
};

const demoEmployer: User = {
  id: 'employer-1',
  email: 'employer@example.com',
  name: 'Jane Smith',
  userType: 'employer',
  company: 'Delicious Restaurant',
  phone: '+381 62 345 6789',
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      userType: null,
      isVip: false,
      // Actions
      login: (user) => set({
        user,
        isAuthenticated: true,
        userType: user.userType,
        isVip: user.isVip || false,
      }),
      logout: () => set({
        user: null,
        isAuthenticated: false,
        userType: null,
        isVip: false,
      }),
      updateUser: (userData) => set((state) => ({
        user: state.user ? { ...state.user, ...userData } : null,
      })),
      setVipStatus: (isVip) => set((state) => ({
        isVip,
        user: state.user ? { ...state.user, isVip } : null,
      })),
    }),
    {
      name: 'jobnest-auth',
    }
  )
);

// For demo purposes, add these functions to login with demo accounts
export const loginWithDemoWorker = () => {
  useAuthStore.getState().login(demoWorker);
};

export const loginWithDemoEmployer = () => {
  useAuthStore.getState().login(demoEmployer);
};