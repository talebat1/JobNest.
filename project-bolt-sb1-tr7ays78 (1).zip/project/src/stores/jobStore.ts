import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  location: string;
  salary: string;
  jobType: 'fullTime' | 'partTime' | 'temporary' | 'seasonal';
  category: string;
  description: string;
  requirements: string[];
  benefits: string[];
  postedDate: string;
  employerId: string;
  featured?: boolean;
}

interface JobState {
  jobs: Job[];
  favorites: string[];
  filters: {
    search: string;
    category: string | null;
    location: string | null;
    jobType: string | null;
    salary: { min: number | null; max: number | null } | null;
  };
  // Actions
  addFavorite: (jobId: string) => void;
  removeFavorite: (jobId: string) => void;
  setFilter: (filterName: string, value: any) => void;
  clearFilters: () => void;
}

// Demo jobs data
const demoJobs: Job[] = [
  {
    id: 'job-1',
    title: 'Head Chef',
    company: 'Delicious Restaurant',
    companyLogo: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    location: 'Belgrade, Serbia',
    salary: '€2000 - €2500',
    jobType: 'fullTime',
    category: 'cook',
    description: 'We are looking for an experienced Head Chef to lead our kitchen team and create exceptional dining experiences for our customers.',
    requirements: [
      'Minimum 5 years of experience as a chef',
      'Strong leadership and team management skills',
      'Creativity and passion for culinary arts',
      'Knowledge of food safety regulations',
    ],
    benefits: [
      'Competitive salary',
      'Health insurance',
      'Paid vacation',
      'Professional development opportunities',
    ],
    postedDate: '2025-03-01',
    employerId: 'employer-1',
    featured: true,
  },
  {
    id: 'job-2',
    title: 'Bartender',
    company: 'Nightlife Bar',
    companyLogo: 'https://images.pexels.com/photos/274192/pexels-photo-274192.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    location: 'Novi Sad, Serbia',
    salary: '€1200 - €1500',
    jobType: 'partTime',
    category: 'bartender',
    description: 'Join our team as a bartender and create amazing cocktails in a vibrant atmosphere.',
    requirements: [
      'Previous bartending experience',
      'Knowledge of classic and modern cocktails',
      'Customer service orientation',
      'Ability to work in a fast-paced environment',
    ],
    benefits: [
      'Flexible schedule',
      'Tips',
      'Staff meals',
      'Fun work environment',
    ],
    postedDate: '2025-03-05',
    employerId: 'employer-2',
  },
  {
    id: 'job-3',
    title: 'Hotel Receptionist',
    company: 'Luxury Hotel',
    companyLogo: 'https://images.pexels.com/photos/261102/pexels-photo-261102.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    location: 'Budva, Montenegro',
    salary: '€1500 - €1800',
    jobType: 'seasonal',
    category: 'receptionist',
    description: 'Seasonal position for a receptionist at our beachfront hotel during the summer season.',
    requirements: [
      'Previous hotel reception experience',
      'Fluent English and Serbian',
      'Computer literacy',
      'Excellent communication skills',
    ],
    benefits: [
      'Staff accommodation',
      'Meals provided',
      'Swimming pool access',
      'End of season bonus',
    ],
    postedDate: '2025-03-10',
    employerId: 'employer-3',
    featured: true,
  },
  {
    id: 'job-4',
    title: 'Waiter/Waitress',
    company: 'Café Central',
    companyLogo: 'https://images.pexels.com/photos/67468/pexels-photo-67468.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    location: 'Zagreb, Croatia',
    salary: '€1100 - €1300',
    jobType: 'fullTime',
    category: 'waiter',
    description: 'We are seeking friendly waiters and waitresses to join our café team and provide excellent service to our customers.',
    requirements: [
      'Previous waiting experience preferred',
      'Customer-focused attitude',
      'Ability to work in shifts',
      'Basic math skills',
    ],
    benefits: [
      'Tips',
      'Staff meals',
      'Training provided',
      'Growth opportunities',
    ],
    postedDate: '2025-03-15',
    employerId: 'employer-4',
  },
  {
    id: 'job-5',
    title: 'Housekeeper',
    company: 'Mountain Resort',
    companyLogo: 'https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    location: 'Zlatibor, Serbia',
    salary: '€900 - €1100',
    jobType: 'fullTime',
    category: 'housekeeper',
    description: 'Join our housekeeping team at a premier mountain resort. Keep our guest rooms and public areas spotless.',
    requirements: [
      'Attention to detail',
      'Physical stamina',
      'Reliability',
      'Team player',
    ],
    benefits: [
      'Accommodation possible',
      'Meals provided',
      'Use of resort facilities',
      'Transportation assistance',
    ],
    postedDate: '2025-03-20',
    employerId: 'employer-5',
  },
];

export const useJobStore = create<JobState>()(
  persist(
    (set) => ({
      jobs: demoJobs,
      favorites: [],
      filters: {
        search: '',
        category: null,
        location: null,
        jobType: null,
        salary: null,
      },
      // Actions
      addFavorite: (jobId) => set((state) => ({
        favorites: [...state.favorites, jobId],
      })),
      removeFavorite: (jobId) => set((state) => ({
        favorites: state.favorites.filter((id) => id !== jobId),
      })),
      setFilter: (filterName, value) => set((state) => ({
        filters: {
          ...state.filters,
          [filterName]: value,
        },
      })),
      clearFilters: () => set({
        filters: {
          search: '',
          category: null,
          location: null,
          jobType: null,
          salary: null,
        },
      }),
    }),
    {
      name: 'jobnest-jobs',
    }
  )
);